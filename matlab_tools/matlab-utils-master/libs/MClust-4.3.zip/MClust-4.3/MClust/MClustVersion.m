function VERSION = MClustVersion()

VERSION = 'MClust 4.3.02; 2014/Dec/18';

