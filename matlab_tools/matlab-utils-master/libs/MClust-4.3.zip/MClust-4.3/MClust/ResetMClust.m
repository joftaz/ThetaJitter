function ResetMClust()
clear global MClustInstance
end